/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.0.27-community-nt : Database - dbdentacare
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbdentacare` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbdentacare`;

/*Table structure for table `tblappointment` */

DROP TABLE IF EXISTS `tblappointment`;

CREATE TABLE `tblappointment` (
  `id` int(20) NOT NULL auto_increment,
  `fullname` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  `mobile` varchar(20) default NULL,
  `date` varchar(10) default NULL,
  `time` varchar(10) default NULL,
  `gender` varchar(50) default NULL,
  `patienttype` varchar(50) default NULL,
  `message` longtext,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblappointment` */

insert  into `tblappointment`(`id`,`fullname`,`email`,`mobile`,`date`,`time`,`gender`,`patienttype`,`message`,`status`) values (1,'Ms. Leena S Patole','ahilya@gmail.com','9456547567','8/8/2023','12:30am','female','A New Patient Appointment','mnkmmmmmmmmmmmm kkkkkkkkkkkkkkkk\r\n','Accept'),(2,'Ms. Megha S Patole','abc@gmail.com','9456547567','10/5/2023','11:30am','male','A Routine Checkup','ghbjjjj    hvbbbbu bgvbbn      mnnnnnn l,         ','Pending'),(6,'Ms.  Reena  M Damodhar','sonalimurkute@gmail.com','9087676543','9/20/2023','4:00pm','female','A New Patient Appointment','gggggggggggggg \r\nlllllllllllll','Accept'),(9,'Ms. RadhaS Sharma','radha@gmail.com','9089878789','9/19/2023','11:00am','female','A Routine Checkup','ghjkj jkljhjhj lllllll kkkkk jjjjjjjj','Pending'),(10,'MS.Megha S Patole','ahilya@gmail.com','9456547567','9/29/2023','12:00pm','female','A Routine Checkup','kjkhk kjklkj bhjbjh jbjhikj','Pending'),(11,'MS.Megha S Patole','ahilya@gmail.com','9456547567','9/29/2023','12:00pm','female','A Routine Checkup','kjkhk kjklkj bhjbjh jbjhikj','Pending'),(12,'MS.Megha S Patole','ahilya@gmail.com','9456547567','9/29/2023','12:00pm','female','A New Patient Appointment','kjkhk kjklkj bhjbjh jbjhikj','Pending'),(13,'Ms. Manali S Annapure','manali@gmail.com','9456547567','9/26/2023','7:00am','female','A Routine Checkup','hjkl hjklk','Accept'),(14,'Ms. Manali S Annapure','manali@gmail.com','9456547567','9/26/2023','7:00am','female','A Routine Checkup','hjkl hjklk','Pending');

/*Table structure for table `tblappointmentstatus` */

DROP TABLE IF EXISTS `tblappointmentstatus`;

CREATE TABLE `tblappointmentstatus` (
  `id` int(11) NOT NULL auto_increment,
  `appintmentid` int(11) default NULL,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblappointmentstatus` */

insert  into `tblappointmentstatus`(`id`,`appintmentid`,`status`) values (1,1,'Accept'),(2,2,'Reject'),(3,2,'Reject'),(4,2,'Reject'),(5,2,'Reject'),(6,7,'Reject'),(7,7,'Reject'),(8,6,'Accept'),(9,2,'Accept'),(10,8,'Reject'),(11,6,'Accept'),(12,13,'Reject'),(13,13,'Reject'),(15,6,'Accept'),(16,6,'Accept'),(17,6,'Accept'),(18,13,'Accept');

/*Table structure for table `tbldoctorreg` */

DROP TABLE IF EXISTS `tbldoctorreg`;

CREATE TABLE `tbldoctorreg` (
  `dr_id` int(20) NOT NULL auto_increment,
  `uname` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  `password` varchar(100) default NULL,
  `mobile` varchar(50) default NULL,
  `code` varchar(100) default NULL,
  `address` longtext,
  `specialist` varchar(100) default NULL,
  PRIMARY KEY  (`dr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbldoctorreg` */

insert  into `tbldoctorreg`(`dr_id`,`uname`,`email`,`password`,`mobile`,`code`,`address`,`specialist`) values (1,'Dr.Mehta','mehtaD@gmail.com','mehta','9809890989','89098','nashik','General Dentist'),(2,'Dr.Shinde','shinde@gmail.com','shinde','9809897898','89889','Pune','Endodontist or Root Canal Specialist'),(3,'Dr.Joshi','joshi22@gmail.com','joshi','9089098909','87987','Dange chouk ,Pune,','Orthodontist');

/*Table structure for table `tblpatientreg` */

DROP TABLE IF EXISTS `tblpatientreg`;

CREATE TABLE `tblpatientreg` (
  `uid` int(20) NOT NULL auto_increment,
  `uname` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  `password` varchar(50) default NULL,
  `mobile` varchar(50) default NULL,
  `address` longtext,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblpatientreg` */

insert  into `tblpatientreg`(`uid`,`uname`,`email`,`password`,`mobile`,`address`) values (1,'Ankush','ankush@gmail.com','a','8908056789','a'),(2,'Ankush','ankush@gmail.com','a','8908056789','a'),(3,'abc','abc@gmail.com','abc','8908056789','pune'),(4,'Reena','reena@gmail.com','reena','9089786756','Nasik'),(5,'Radha','radha@gmail.com','radha','9089090989','Pune'),(6,'Manali','manali@gmail.com','manali','7898909098','Pune');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
