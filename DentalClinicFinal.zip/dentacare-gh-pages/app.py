from flask import *
import pymysql
from flask import flash, session
from werkzeug.utils import secure_filename
import os

import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 

app = Flask(__name__)
app.secret_key = 'super secret key'
app.config['SESSION_TYPE'] = 'filesystem'



def dbConnection():
    try:
        connection = pymysql.connect(host='localhost', user='root', password='root', database='dbdentacare')
        return connection
    except:
        print('something went wrong in database connection...')
def dbClose():
    try:
        dbConnection().close()
    except:
        print('Something went wrong in close DB conection...')
    
def SessionExists():
    if session.get("uname"):       
        return True
    return False    
###################################################        SEND MAIL TO USER        ##################################
def sendmailtouser(usermail,mailbody):
    fromaddr = "pranalibscproject@gmail.com"
    toaddr = usermail          
            #instance of MIMEMultipart 
    msg = MIMEMultipart()           
            # storing the senders email address   
    msg['From'] = fromaddr           
            # storing the receivers email address  
    msg['To'] = toaddr          
            # storing the subject  
    msg['Subject'] = "Regarding Appointment Status!"          
            # string to store the body of the mail 
    body = mailbody   
            
    msg.attach(MIMEText(body, 'plain'))          
            # creates SMTP session 
    s = smtplib.SMTP('smtp.gmail.com', 587)          
            # start TLS for security 
    s.starttls()          
            # Authentication 
    s.login(fromaddr, "wkwfgosewcljcpqh") 
          
            # Converts the Multipart msg into a string 
    text = msg.as_string() 
          
            # sending the mail 
    s.sendmail(fromaddr, toaddr, text) 
          
            # terminating the session 
    s.quit() 
    
######################################################################################################################
@app.route("/", methods=['POST' , 'GET'])
def main():
    return render_template('main.html') 
##########################################      REGISTER        ###########################################################
@app.route("/patientRegister", methods=['POST' , 'GET'])
def patientRegister():
  if request.method == 'POST':
        uname = request.form['uname']
        email = request.form['email']
        password = request.form['password']
        mobile = request.form['mobile']
        address = request.form['address']
        print(uname)
        try:
            con = dbConnection()
            print('Connection Done....')
            cursor = con.cursor()
            sql = "INSERT INTO tblpatientreg(uname,email,password,mobile,address) VALUES(%s,%s,%s,%s,%s)"
            val = (uname,email,password,mobile,address)
            cursor.execute(sql,val)
            print("query submitted...")
            con.commit()
            return render_template('login.html')
        except:
            con.rollback()
            msg='error occured....'
            return render_template('register.html', msg=msg)
        finally:
            dbClose()
  return render_template('patientRegister.html') 
#3#########################################    DR. REGISTER       ###########################################################

@app.route("/doctorRegister", methods=['POST' , 'GET'])
def doctorRegister():
    if request.method == 'POST':
          uname = request.form['uname']
          email = request.form['email']
          password = request.form['password']
          mobile = request.form['mobile']
          code = request.form['code']
          address = request.form['address']
          specialist = request.form['specialist']
          print(uname)
          try:
              con = dbConnection()
              print('Connection Done....')
              cursor = con.cursor()
              sql = "INSERT INTO tbldoctorreg(uname,email,password,mobile,code,address,specialist) VALUES(%s,%s,%s,%s,%s,%s,%s)"
              val = (uname,email,password,mobile,code,address,specialist)
              cursor.execute(sql,val)
              print("query submitted...")
              con.commit()
              return render_template('login.html')
          except:
              con.rollback()
              msg='error occured....'
              return render_template('doctorRegister.html', msg=msg)
          finally:
              dbClose()
    return render_template('doctorRegister.html') 

################################################        LOGIN       #################################################################
@app.route("/login", methods=['POST' , 'GET'])
def login():
    if request.method=="POST":
        uname = request.form['uname']
        password = request.form['password']
        print(password)
        con = dbConnection()
        cursor = con.cursor()
        print("connection done....")
        
        doctor_count = cursor.execute("SELECT * FROM tbldoctorreg WHERE uname=%s AND password=%s",(uname, password))
        dr_result = cursor.fetchone()
        print(dr_result)
        
        patient_count = cursor.execute("SELECT * FROM tblpatientreg WHERE uname=%s AND password=%s",(uname, password))
        pt_result = cursor.fetchone()
        print(pt_result)
        
        if doctor_count==1:
            uname = dr_result[1]
            session['uid'] = dr_result[0]
            session['uname'] = uname  
            print("Doctor uname="+uname)
            return redirect(url_for('doctorHome'))
    
        elif patient_count==1:          
            uname = pt_result[1]
            session['uid'] = pt_result[0]
            session['uname'] = uname  
            print("Patient uname="+uname)            
            return redirect(url_for('patientHome'))
        
        elif (uname =="dentalclinic" and password =="12345678"):
            return redirect(url_for('receptionistHome'))
        else:
            return render_template("login.html")
    
    return render_template('login.html')
###################################################         DOCTOR HOME           ###################################################
@app.route("/doctorHome", methods=['POST' , 'GET'])
def doctorHome():
    if not SessionExists():
        return render_template('login.html')
    return render_template('doctorHome.html') 
###################################################         ACCEPTED PATIENT LIST   ###############################################
@app.route("/acceptedPatient", methods=['POST' , 'GET'])
def acceptedPatient():
    con = dbConnection()
    cursor = con.cursor()
    status = "Accept"
    result = cursor.execute("SELECT * FROM tblappointment WHERE status =%s",status)
    details = cursor.fetchall()
    return render_template('acceptedPatient.html',details=details) 
###################################################         DOCTOR VIEW PATIENT DETAILS           ###################################################
@app.route("/viewDoctor/<string:id>", methods=['POST' , 'GET'])
def viewDoctor(id):
    con = dbConnection()
    cursor = con.cursor()
    result = cursor.execute("SELECT * FROM tblappointment WHERE id = %s", (id))
    info = cursor.fetchone()
    con.commit()
    return render_template('viewDoctor.html',info=info) 
###################################################         PATIENT HOME        ###################################################
@app.route("/patientHome", methods=['POST' , 'GET'])
def patientHome():
    if not SessionExists():
        return render_template('login.html')
    return render_template('patientHome.html')

##################################################      APPOINTMENT         ###################################################
@app.route("/appointment", methods=['POST' , 'GET'])
def appointment():
    if request.method=="POST":
       
        fullname = request.form['fullname']
        email = request.form['email']
        mobile = request.form['mobile']
        date = request.form['date']
        time = request.form['time']
        gender = request.form['gender']
        patienttype = request.form['patienttype']
        print("patienttype= ")
        print(patienttype)
        message = request.form['message']
        status ="Pending"
        
        print(gender)
        con = dbConnection()
        cursor = con.cursor()
        print(" connection done")
        query = "INSERT INTO tblappointment(fullname,email,mobile,date,time,gender,patienttype,message,status) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (fullname,email,mobile,date,time,gender,patienttype,message,status)
        result = cursor.execute(query,val)
        print ("result= ",result)
        # appintmentid = str(result[0])
        # session['id'] = appintmentid
        print("Query submitted...")
        msg = "Appointment Submited Successfuly....."
        con.commit()
        return render_template('appointment.html',msg=msg)
    return render_template('appointment.html')

############################################        RECEPTIONIST        ##################################################################################

@app.route("/receptionistHome", methods=['POST' , 'GET'])
def receptionistHome():
    
    return render_template('receptionistHome.html')
  
#############################################       PATIENT LIST       #########################################################
@app.route("/allpatient", methods=['POST' , 'GET'])
def allpatient():
    print("allpatient Form")
    con = dbConnection()
    cursor = con.cursor()
    result = cursor.execute("SELECT * FROM tblappointment")
    details = cursor.fetchall()
   
    print("details")
   # print(details)
    con.commit()   
    return render_template('allpatient.html',details=details)
##################################################      VIEW PATIENT       #######################################################
@app.route("/viewPatient/<string:id>", methods=['POST' , 'GET'])
def viewPatient(id):
    con = dbConnection()
    cursor = con.cursor()
    result = cursor.execute("SELECT * FROM tblappointment WHERE id = %s", (id))
    info = cursor.fetchone()
    con.commit()
    print("result")
    print(result)
        
    return render_template('viewPatient.html',info=info)
#######################################     ACCEPT APPOINTMENT     ################################################################
@app.route("/acceptappointment/<string:id>", methods=['POST' , 'GET'])
def acceptappointment(id):
    con = dbConnection()
    cursor = con.cursor()
    appintmentid = id
    print("appintmentid = ")
    print(appintmentid)
    
    query = cursor.execute("SELECT email from tblappointment WHERE id =%s",(appintmentid))
    emailResult = cursor.fetchone()
    email = emailResult[0]
    
    status = "Accept"
    result = "INSERT INTO tblappointmentstatus(appintmentid,status) VALUES (%s,%s) "
    val = (appintmentid,status)
    finalresult = cursor.execute(result,val)
    
    ##############     EMAIL  ##############   
    usermail = email
    emailbody = "hi....\n Your Appointment is Accepted...please come at that time..."
    sendmailtouser(usermail,emailbody)        
    
    updateQuery = cursor.execute("UPDATE tblappointment SET status=%s WHERE id=%s",(status,appintmentid))
    
    msg="Appointment Accepted...."
    print(msg)
    con.commit()
    return redirect(url_for('allpatient'))
#######################################     REJECT APPOINTMENT     ################################################################
@app.route("/rejectappointment/<string:id>", methods=['POST' , 'GET'])
def rejectappointment(id):
    appintmentid = id
    print("appintmentid = ")
    print(appintmentid)
    con = dbConnection()
    cursor = con.cursor()
    query = cursor.execute("SELECT email from tblappointment WHERE id =%s",(appintmentid))
    emailResult = cursor.fetchone()
    email = emailResult[0]
    print(email)
    status = "Reject"
    result = "INSERT INTO tblappointmentstatus(appintmentid,status) VALUES (%s,%s) "
    val = (appintmentid,status)
    finalresult = cursor.execute(result,val)
    con.commit()
    result = cursor.execute("DELETE FROM tblappointment WHERE id = %s", (appintmentid))
    print(result)
    ##############     EMAIL  ##############
    usermail = email
    mailbody = "Sorry....\n Your Appointment is Rejected...Doctor is not available that time...please make an another appointment.." 
    sendmailtouser(usermail,mailbody)
    #######################################
    con.commit()
    
    return redirect(url_for('allpatient'))

#3############################################################################################################
@app.route("/about", methods=['POST' , 'GET'])
def about():
    if not SessionExists():
        return render_template('login.html')
    return render_template('about.html')   

@app.route("/contact", methods=['POST' , 'GET'])
def contact():
    if not SessionExists():
        return render_template('login.html')
    return render_template('contact.html')  

@app.route("/logout", methods=['POST', 'GET'])
def logout():
    session['uname'] = None
    return render_template('main.html')
    




##########################################################################################################################

if __name__ == "__main__":
    app.run("0.0.0.0") 
    # app.run(debug=True)    

